<?php namespace App\Models;

use CodeIgniter\Model;
use Hashids\Hashids;

class CategoryModel extends Model
{
    protected $table      = 'categories';
    protected $primaryKey = 'id';

    protected $returnType = 'object';
    protected $useSoftDeletes = true;

    protected $allowedFields = ['hash_id', 'user_id', 'title', 'color', 'is_default'];

    protected $useTimestamps = true;
    // protected $createdField  = 'created_at';
    // protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    protected $validationRules    = 'category';
    // protected $validationMessages = [];
    protected $skipValidation     = false;
    protected $afterInsert = ['hashids'];

	protected function hashids(array $data) {
		$hashids = new Hashids($_ENV["hashids.salt"], $_ENV["hashids.padding"]);
		$hash_id = $hashids->encode($data['id']);
		return $this->update($data['id'], ['hash_id' => $hash_id]);
	}
}