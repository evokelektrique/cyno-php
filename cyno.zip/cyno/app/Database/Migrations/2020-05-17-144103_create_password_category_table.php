<?php namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreatePasswordCategoryTable extends Migration
{
	public function up()
	{
		$this->forge->addField([
			'password_id' => [
				'type' => 'BIGINT',
				'unsigned' => TRUE,
			],
			'category_id' => [
				'type' => 'BIGINT',
				'unsigned' => TRUE,
			],
		]);
		$this->forge->addKey('password_id', TRUE);
		$this->forge->addKey('category_id', TRUE);
		$this->forge->createTable('password_category');
	}

	//--------------------------------------------------------------------

	public function down()
	{
		$this->forge->dropTable('password_category');
	}
}
