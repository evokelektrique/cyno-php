<?php
namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/**
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Landing');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/**
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */


$routes->get('/', 'Landing::index', ['as' => 'root']);
// $routes->cli('jobs/encrypt/(:segment)', 'Jobs::encrypt/$1');





// Authentication
$routes->group('auth', function ($routes) {
    // Login
    $routes->get('login', 'Login::index', ['as' => 'user_login']);
    $routes->post('login/validation', 'Login::validation', ['as' => 'user_login_validation']);

    // Registration
    $routes->get('register', 'Register::index', ['as' => 'user_register']);
    $routes->post('register', 'Register::create', ['as' => 'user_create']);

    // Email
    $routes->get('validate_email/(:hash)', 'Email::validate_email/$1', ['as' => 'user_validate_email']);
});



// Dashboard
$routes->group('dashboard', function($routes) {

    $routes->get('/', 'Dashboard::index', ['as' => 'dashboard']);

	// Profile
	$routes->group('profile', function($routes) {
		$routes->get('/', 'Profile::index', ['as' => 'dashboard_profile']);
        $routes->get('settings', 'Profile::settings', ['as' => 'dashboard_profile_settings']);
        $routes->put('validate_settings', 'Profile::validate_settings');
		$routes->delete('logout', 'Profile::logout', ['as' => 'dashboard_profile_logout']);
	});


    // Passwords
    $routes->group('passwords', function($routes) {
        $routes->get('/', 'Passwords::index', ['as' => 'dashboard_passwords']);
        $routes->get('new', 'Passwords::new', ['as' => 'dashboard_password_new']);
        $routes->post('create', 'Passwords::create', ['as' => 'dashboard_password_create']);
        $routes->get('(:hash)', 'Passwords::show/$1', ['as' => 'dashboard_password_show']);
        $routes->put('(:hash)', 'Passwords::update/$1', ['as' => 'dashboard_password_update']);
        $routes->delete('(:hash)', 'Passwords::delete/$1', ['as' => 'dashboard_password_delete']);
    });

    // Categories
    $routes->group('categories', function($routes) {
        $routes->get('/', 'Categories::index', ['as' => 'dashboard_categories']);
        $routes->get('new', 'Categories::new', ['as' => 'dashboard_category_new']);
        $routes->post('create', 'Categories::create', ['as' => 'dashboard_category_create']);
        $routes->get('(:hash)', 'Categories::show/$1', ['as' => 'dashboard_category_show']);
        $routes->get('(:hash)/edit', 'Categories::edit/$1', ['as' => 'dashboard_category_edit']);
        $routes->put('(:hash)', 'Categories::update/$1', ['as' => 'dashboard_category_update']);
        $routes->delete('(:hash)', 'Categories::delete/$1', ['as' => 'dashboard_category_delete']);
    });

});











if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
