<?php
namespace Config;
use CodeIgniter\Config\BaseConfig;

class Config extends BaseConfig {
	// public $site;
}