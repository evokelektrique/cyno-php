<?= $this->extend('layouts/Authentication') ?>
<?php if($session->has('alert')): ?>
	<?= var_dump($session->alert) ?>
<?php endif; ?>

<?= $this->section('wrapper') ?>
	<?= $this->include('landing/partials/header') ?>
	
	Login
	<?= form_open(base_url(route_to('App\Controllers\Login::validation'))) ?>
	<?php
		$email_input = [
			'name' 			=> 'user[email]',
			'id' 			=> 'user[id]',
			'value' 		=> old('user.email'),
			'maxlength'	 	=> '100',
			'type' 			=> 'email',
			'placeholder' 	=> 'email ...',
		];
		$password_input = [
			'name' => 'user[password]',
			'id' 	=> 'password',
			'value' => '',
			'maxlength' => '100',
			'type' => 'password',
			'placeholder' => 'password ...',
		];
		$submit_input = [
			'name' => 'submit',
			'id' => 'submit',
			'value' => 'submit!',
			'type' => 'submit'
		];
	?>

	<?= form_input($email_input); ?>
	<?= form_password($password_input); ?>
	<?= form_submit($submit_input); ?>
<?= form_close() ?>

<?= $this->endSection() ?>
