<?php if($session->has('alert')): ?>
	<?= var_dump($session->alert) ?>
<?php endif; ?>

<?php if($session->has('user') && $session->user['is_logged_in']): ?>
<?= form_open(base_url(route_to('dashboard_profile_logout'))) ?>
	<?= form_hidden('_method', 'DELETE') ?>
	<?= form_submit('logout', 'Logout !') ?>
<?= form_close() ?>
	<a href='<?= base_url(route_to('dashboard')) ?>'>Dashboard</a>
<?php else: ?>
<a href="<?= base_url(route_to('user_login')) ?>">Login</a> 
<a href="<?= base_url(route_to('user_register')) ?>">Register</a>
<?php endif; ?>

<br>

Landing

