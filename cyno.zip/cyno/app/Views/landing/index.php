<?= $this->extend('layouts/Landing') ?>

<?= $this->section('wrapper') ?>
	<!-- Header -->
	<?= $this->include('landing/partials/header') ?>
<?= $this->endSection('wrapper') ?>