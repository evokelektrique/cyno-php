<?= $this->extend('layouts/Authentication') ?>


<?= $this->section('wrapper') ?>
	<?= $this->include('landing/partials/header') ?>

Register !
<?= form_open(base_url(route_to('App\Controllers\Register::create'))) ?>
	<?php  
		$email_input = [
			'name' 			=> 'user[email]',
			'id' 			=> 'user[id]',
			'value' 		=> old('user.email'),
			'maxlength'	 	=> '100',
			'type' 			=> 'email',
			'placeholder' 	=> 'email ...',
		];
		echo form_input($email_input);
	?>
	<?php 
		$password_input = [
			'name' => 'user[password]',
			'id' 	=> 'password',
			'value' => '',
			'maxlength' => '100',
			'type' => 'password',
			'placeholder' => 'password ...',
		];
		echo form_password($password_input);
	?>

	<?php
		$submit_input = [
			'name' => 'submit',
			'id' => 'submit',
			'value' => 'submit!',
			'type' => 'submit'
		];
		echo form_submit($submit_input);
	?>
<?= form_close() ?>
<?= $this->endSection() ?>