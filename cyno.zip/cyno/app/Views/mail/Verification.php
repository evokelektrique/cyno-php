Hey ! here is your account verification link: 
<br>
<b>Click <a href="<?= base_url(route_to('user_validate_email', $hash)) ?>">here</a> to activate your account</b>