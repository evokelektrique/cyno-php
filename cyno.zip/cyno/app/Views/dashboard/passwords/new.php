<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('wrapper') ?>
	<?= $this->include('dashboard/partials/header') ?> 

	<?= form_open(base_url(route_to('App\Controllers\Passwords::create'))) ?>
		<label>masterkey:</label>
		<?= form_password('masterkey', '') ?>
		<br>
		<label>masterkey_ad:</label>
		<?= form_password('masterkey_ad', '') ?>
		<br>
		<label>password:</label>
		<?= form_password('cipher_text', '') ?>
		<br>
		<label>category:</label>
		<?= form_multiselect('categories[]', $categories, $default_category); ?>
		<br>
		<?= form_submit('submit', 'submit!') ?>

	<?= form_close() ?>

<?= $this->endSection() ?>