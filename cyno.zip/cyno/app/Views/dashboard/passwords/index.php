<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('wrapper') ?>
	<?= $this->include('dashboard/partials/header') ?> 
	<h1>Password list</h1>

	<?php foreach($passwords as $password): ?>
		<div id='password-<?=$password->hash_id?>'>
			<code style="color: pink"><?= $password->cipher ?></code>
			<a href="<?= base_url(route_to('dashboard_password_show', $password->hash_id)) ?>">Show</a>
			<?= form_open(route_to('App\Controllers\Passwords::delete', $password->hash_id), ['style' => 'display: inline-block']) ?>
				<?= form_hidden('_method', 'DELETE') ?>
				<?= form_submit('delete', 'DELETE!') ?>
			<?= form_close() ?>
		</div>
	<?php endforeach; ?>


<?= $this->endSection() ?>