<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('wrapper') ?>
	<?= $this->include('dashboard/partials/header') ?> 
	<h1>Password list</h1>

	<div id='password-<?=$password->hash_id?>'>
		<code style="color: pink"><?= $password->hash_id ?> - <?= $password->cipher ?></code>
		<h2>categories:</h2> 
		<?php foreach($categories as &$category): ?>
			<a href="<?= base_url(route_to("dashboard_category_show", $category->hash_id)) ?>"><?= $category->title ?></a> <br>
		<?php endforeach; ?>
	</div>
<?= $this->endSection() ?>