<?= $this->extend('layouts/Dashboard') ?>

<?= $this->section('wrapper') ?>	
	<?= $this->include('dashboard/partials/header') ?> 
<?= $this->endSection('wrapper') ?>