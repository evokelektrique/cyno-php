<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('wrapper') ?>
	<?= $this->include('dashboard/partials/header') ?> 

	<?= form_open(base_url(route_to('dashboard_category_update', $category->hash_id))) ?>
		<?= form_hidden('_method', 'PUT') ?>
		<label>title:</label>
		<?= form_input('title', $category->title) ?>
		<br>
		<label>color:</label>
		<?= form_input('color', $category->color) ?>
		<br>
		<?= form_submit('submit', 'submit!') ?>

	<?= form_close() ?>

<?= $this->endSection() ?>