<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('wrapper') ?>
	<?= $this->include('dashboard/partials/header') ?> 

	<?= form_open(base_url(route_to('dashboard_category_create'))) ?>
		<label>title:</label>
		<?= form_input('title', old('title', '')) ?>
		<br>
		<label>color:</label>
		<?= form_input('color', old('color', '')) ?>
		<br>
		<?= form_submit('submit', 'submit!') ?>

	<?= form_close() ?>

<?= $this->endSection() ?>