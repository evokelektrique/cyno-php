<?= $this->extend('layouts/dashboard') ?>

<?= $this->section('wrapper') ?>
	<?= $this->include('dashboard/partials/header') ?> 
	<h1>Category list</h1>

	<?php foreach($categories as $category): ?>
		<div id='category-<?=$category->hash_id?>'>
			<code style="color: <?php $category->color ?>"><?= ($category->title == 'DEFAULT') ?'پیشفرض':NULL ?></code>
			<a href="<?= base_url(route_to('dashboard_category_show', $category->hash_id)) ?>">Show - <?= $category->title ?></a>
			<?= form_open(route_to('dashboard_category_delete', $category->hash_id), ['style' => 'display: inline-block']) ?>
				<?= form_hidden('_method', 'DELETE') ?>
				<?= form_submit('delete', 'DELETE!') ?>
			<?= form_close() ?>
		</div>
	<?php endforeach; ?>


<?= $this->endSection() ?>