<?php if($session->has('alert')): ?>
	<?= var_dump($session->alert) ?>
<?php endif; ?>
<?php if($session->has('errors')): ?>
	<?php foreach($session->errors as $key => $error): ?>
		<?= $key ?> => <?= $error ?> <br>
	<?php endforeach; ?>
<?php endif; ?>

<?= form_open(base_url(route_to('dashboard_profile_logout'))) ?>
	<?= form_hidden('_method', 'DELETE') ?>
	<?= form_submit('logout', 'Logout !') ?>
<?= form_close() ?>

<b><a href='<?= base_url(route_to('dashboard')) ?>'>Dashboard</a></b>
<b><a href='<?= base_url(route_to('dashboard_profile_settings')) ?>'>Profile Settings</a></b>

<b><a href='<?= base_url(route_to('dashboard_passwords')) ?>'>Passwords</a></b>
<b><a href='<?= base_url(route_to('dashboard_password_new')) ?>'>Passwords new</a></b>

<b><a href='<?= base_url(route_to('dashboard_categories')) ?>'>Categories</a></b>
<b><a href='<?= base_url(route_to('dashboard_category_new')) ?>'>New Category</a></b>

