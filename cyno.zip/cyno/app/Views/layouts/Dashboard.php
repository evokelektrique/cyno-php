<!DOCTYPE html>
<html>
<head>
	<title>Dashboard layout</title>
	<link rel="stylesheet" type="text/css" href="<?= base_url('public/css/landing.css')?>">
</head>
<body>
	<!-- Wrapper -->
	<div id="wrapper">
		<?= $this->renderSection('wrapper') ?>
	</div>

</body>
</html>