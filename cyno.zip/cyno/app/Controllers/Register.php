<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;

class Register extends BaseController {

	public function index() {
		$data = [
			'session' => session()
		];
		return view('landing/register', $data);
	}

	public function create() {
		// Loading model
		$model = new UserModel();

		// Loading services
		$validation = \Config\Services::validation();
		$encrypter 	= \Config\Services::encrypter();

		// Incomming data
		$request_data = [
			'email' 	=> $this->request->getVar('user[email]'),
			'password' 	=> $this->request->getVar('user[password]'),
		];
		$data = [
			'email' 	=> $request_data['email'],
			'password' 	=> base64_encode($encrypter->encrypt($request_data['password']))
		];
		// Validate data
		if($validation->run($data, 'register')) {
			$save = $model->insert($data);
			if($save > 0) {
				// Send email
				$data['user_id'] = $save;
				$category_data = [
					'user_id' => $save,
					'title' => 'پیشفرض',
					'color' => '#f0f0f0',
					'is_default' => TRUE,
				];
				$email = \CodeIgniter\Events\Events::trigger('user_registration', $data);
				$default_category= \CodeIgniter\Events\Events::trigger('user_default_category',$category_data);
				// Validate email
				if($email) {
					return redirect('user_login')->with('alert', [
						'status' => 'SUCCESS',
						'message' => 'email sent'
					]);
				} else {
					return redirect()->back()->with('alert', [
						'status' => 'FAIL',
						'message' => 'cannot send email'
					]);
				}
			} else {
				return redirect()->back()->withInput();
			}
		} else {
			// var_dump($validation->listErrors());
			return redirect()->back()->withInput();
		}
	}
	
}