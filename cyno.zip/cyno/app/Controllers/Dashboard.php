<?php namespace App\Controllers;

use CodeIgniter\Controller;

class Dashboard extends BaseController {

	public function index() {
		$data = [
			'session' => session()
		];
		return view('dashboard/index', $data);
	}

}