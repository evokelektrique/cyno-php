<?php namespace App\Controllers;

use CodeIgniter\Controller;
use \App\Models\CategoryModel;
use \App\Models\PasswordModel;
use Hashids\Hashids;
class Categories extends BaseController {

	protected $model;
	protected $hashids;

	public function __construct() {
		$this->model = new CategoryModel();
		$this->hashids = new Hashids($_ENV["hashids.salt"], $_ENV["hashids.padding"]);
	}

	public function index() {
		$categories = $this->model
			->where('user_id', $this->session->user['id'])
			->findAll();
		$data = [
			'session' => $this->session,
			'categories' => $categories
		];
		return view('dashboard/categories/index', $data);
	}


	public function new() {
		$data = [
			'session' => $this->session,
		];
		return view('dashboard/categories/new', $data);
	}

	public function create() {
		// Input data
		$input_data = [
			'title' => $this->request->getPost('title'),
			'color' => $this->request->getPost('color'),
		];

		// Validate data
		$validation = \Config\Services::validation();
		if(!$validation->run($input_data, 'category')) {
			$this->session->setFlashdata('errors', $validation->getErrors());
			return redirect()->back()->with('alert', [
				'status' => 'FAIL',
				'message' => 'validation failed.'
			]);
		}

		$data = [
			'user_id' => $this->session->user['id'],
			'title' => $input_data['title'],
			'color' => $input_data['color'],
		];
		// Insert data
		if(count($this->model->where('title', $data['title'])->where('user_id',$data['user_id'])->findAll()) == 0) {
			$category_id = $this->model->insert($data);
			if($category_id > 0) {
				return redirect()->route('dashboard_categories')->with('alert', [
					'status' => 'SUCCESS',
					'message' => 'Category created.'
				]);
			} else {
				return redirect()->route('dashboard_categories')->with('alert', [
					'status' => 'SUCCESS',
					'message' => 'Category not created.'
				]);
			}
		} else {
			$this->session->setFlashdata('alert', ['status' => 'FAIL', 'message' => 'Category name must be unique']);
			return redirect()->back()->withInput();
		}
	}


	public function show($hash_id) {
		$category = $this->model
			->where('user_id', $this->session->user['id'])
			->where('hash_id', $hash_id)
			->first();
		if(!empty($category)) {
			$password_model = new PasswordModel();
			$passwords = $password_model
				->select('*')
				->join('password_category', 'passwords.id = password_category.password_id')
				->where('user_id', $this->session->user['id'])
				->where('category_id', $this->hashids->decode($hash_id))
				->findAll();
			$data = [
				'session' => $this->session,
				'category' => $category,
			];
			if(!empty($passwords)) {
				$data['passwords'] = $passwords;
			}
			return view('dashboard/categories/show', $data);
		} else {
			return redirect()->route('dashboard_categories')->with('alert', [
				'status' => 'SUCCESS',
				'message' => 'Category not found.'
			]);

		}
	}


	public function edit($hash_id) {
		$category = $this->model
			->where('user_id', $this->session->user['id'])
			->where('hash_id', $hash_id)
			->first();
		if($category->is_default) {
			return redirect()->route('dashboard_categories')->with('alert', [
				'status' => 'FAIL',
				'message' => 'Default category is not editable.'
			]);
		} else {			
			if(!empty($category)) {
				$data = [
					'session' => $this->session,
					'category' => $category
				];
				return view('dashboard/categories/edit', $data);
			} else {
				return redirect()->route('dashboard_categories')->with('alert', [
					'status' => 'FAIL',
					'message' => 'Category not found.'
				]);
			}
		}
	}



	public function update($hash_id) {
		$category = $this->model
			->where('user_id', $this->session->user['id'])
			->where('hash_id', $hash_id)
			->first();
		if(!empty($category)) {
			$data = [
				'id' => $category->id,
				'title' => $this->request->getPost('title'),
				'color' => $this->request->getPost('color'),
			];
			$save_record_id = $this->model->save($data);
			if($save_record_id > 0) {
				return redirect()->back()->with('alert', [
					'status' => 'SUCCESS',
					'message' => "{$category->title} Category edited."
				]);
			}
		} else {
			return redirect()->back()->with('alert', [
				'status' => 'SUCCESS',
				'message' => 'Category not found.'
			]);
		}
	}




	public function delete($hash_id) {
		$category = $this->model
			->where('user_id', $this->session->user['id'])
			->where('hash_id', $hash_id)
			->first();
		if(!empty($category)) {
			if($category->is_default) {
				return redirect()->route('dashboard_categories')->with('alert', [
					'status' => 'SUCCESS',
					'message' => 'Default category is not deletable.'
				]);
			} else {
				$this->model->delete($category->id);
				return redirect()->back()->with('alert', [
					'status' => 'SUCCESS',
					'message' => 'Category Deleted.'
				]);
			}
		} else {
			return redirect()->back()->with('alert', [
				'status' => 'SUCCESS',
				'message' => 'Category not found.'
			]);
		}
	}


}