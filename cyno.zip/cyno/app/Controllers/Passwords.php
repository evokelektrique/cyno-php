<?php namespace App\Controllers;

use CodeIgniter\Controller;
use \App\Libraries\Vault;
use \App\Models\PasswordModel;
use \App\Models\CategoryModel;
use \App\Models\PasswordCategoryModel;
use Hashids\Hashids;

class Passwords extends BaseController {

	protected $model;
	protected $category_model;
	protected $hashids;

	public function __construct() {
		$this->model = new PasswordModel();
		$this->category_model = new CategoryModel();
		$this->hashids = new Hashids($_ENV["hashids.salt"], $_ENV["hashids.padding"]);
	}

	public function index() {
		$passwords = $this->model->where('user_id', $this->session->user['id'])->findAll();
		// $data = [
		// 	'session' => $this->session,
		// 	'passwords' => $passwords
		// ];

		// return view('dashboard/passwords/index',$data);


		$data = [
			'masterkey' 	=> 'mymasterkey',
			'masterkey_ad' 	=> 'ad',
			'cipher_text' 	=> 'mysecurepassword',
			'user_id' => 1
		];


		$vault = new Vault();
		$encrypted = $vault->encrypt($data);
		echo "User Input data: <br>";
		var_dump($data);
		echo('Encrypted stuff:<br>');
		var_dump($encrypted);
	}




























	public function new() {
		$categories = (array)$this->category_model->where('user_id', $this->session->user['id'])->orderBy('id','desc')->findAll();
		$categories = array_column($categories, 'title', 'hash_id');
		$default_category = (array)$this->category_model->where('user_id', $this->session->user['id'])->where('is_default', 1)->findAll();
		$default_category = array_column($default_category, 'hash_id');
		$data = [
			'session' => $this->session,
			'categories' => $categories,
			'default_category' => $default_category
		];
		return view('dashboard/passwords/new',$data);
	}
 	
	public function create() {
		// Inputs data
		$data = [
			'masterkey' 	=> $this->request->getPost('masterkey'),
			'masterkey_ad' 	=> $this->request->getPost('masterkey_ad'),
			'cipher_text' 	=> $this->request->getPost('cipher_text'),
			'categories' 	=> $this->request->getVar('categories')
		];

		// Validation data
		$validation = \Config\Services::validation();
		if(!$validation->run($data, 'password_create')) {
			$this->session->setFlashdata('errors', $validation->getErrors());
			return redirect()->back()->with('alert', ['status' => 'FAIL', 'message' => 'validation failed']);
		}
		// Encrypting Data
		$vault = new Vault();
		$encrypted = $vault->encrypt($data);
		// Loading Model
		$model_data = [
			'salt' => $encrypted['config']['salt'],
			'nonce' => $encrypted['config']['nonce'],
			'cipher' => $encrypted['encrypted'],
			'user_id' => $this->session->user['id']
		];
		// Inserting data
		$insert_id = $this->model->insert($model_data);
		if($insert_id > 0) {
			// Inserting category batch
			$password_category_model = new PasswordCategoryModel();
			$categories_batch = [];
			foreach($data['categories'] as $key => &$value) {
				array_push($categories_batch, [
					'password_id' => $insert_id,
					'category_id' => $this->hashids->decode($value)
				]);
			}
			$insert_batch =$password_category_model->insertBatch($categories_batch);
			return redirect()->route('dashboard_passwords')->with('alert', [
				'status' => 'SUCCESS',
				'message'=> 'Password Successfully created.'
			]);
		} else {
			return redirect()->route('dashboard_passwords')->with('alert', [
				'status' => 'FAIL',
				'message'=> 'Operation Failed.'
			]);
		}
	}

	public function show($hash_id) {
		$_hash_id = $this->hashids->decode($hash_id);
		var_dump($_hash_id);
		$categories = $this->category_model
			->select('*')
			->join('password_category', 'categories.id = password_category.category_id')
			->where('password_id', $_hash_id)
			->findAll();

		$password = $this->model->where('user_id', $this->session->user['id'])->where('hash_id', $hash_id)->first();
		$data = [
			'session' => $this->session,
			'password' => $password,
			'categories' => $categories
		];

		if(!empty($password)) {
			return view('dashboard/passwords/show', $data);
		} else {
			return redirect()->route('dashboard_passwords')->with('alert', [
				'status' => 'SUCCESS',
				'message' => 'Password successfully deleted'
			]);
		}

	}



	public function delete($hash_id) {
		$password = $this->model
			->where('hash_id', $hash_id)
			->where('user_id', $this->session->user['id'])->first();
		$_hash_id = $this->hashids->decode($hash_id);
		$categories = $this->category_model
			->select('*')
			->join('password_category', 'categories.hash_id = password_category.category_hash_id')
			->where('password_id', $_hash_id)
			->findAll();
		var_dump($categories);
		// if(!empty($password)) {
		// 	$password_category_model = new PasswordCategoryModel();
		// 	foreach($categories_hash_ids as &$cat_hash_id) {
		// 		$cat = $this->category_model->select(['title', 'color', 'hash_id', 'is_default'])->where('hash_id' , $cat_hash_id->category_hash_id)->first();
		// 		$this->password_category_model->delete($cat->id);
		// 	}
		// 	$this->model->delete($password->id);
		// 	return redirect()->back()->with('alert', [
		// 		'status' => 'SUCCESS',
		// 		'message' => 'Password successfully deleted'
		// 	]);
		// } else {
		// 	return redirect()->back()->with('alert', [
		// 		'status'  => 'FAIL',
		// 		'message' => 'Password unsuccessfully deleted'
		// 	]);
		// }
	}

}